# init file for the wrpoly package
# Authors: Danielle Alverson
# created: 2023-02-2
# last modified: 2023-03-2
# version: 0.0.8

# import modules

from .ThinFilmDataCreation import *