# thinfilm-toy-data-tool
A tool to create simulated 2D thin film data
