# thinfilm-toy-data-tool
A tool to creat simulated 2D thin film data
